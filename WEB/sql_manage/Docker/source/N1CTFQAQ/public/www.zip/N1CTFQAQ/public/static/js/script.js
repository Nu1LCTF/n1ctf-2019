$("#button").click(function(){
    var host = $("#host").val();
    var user = $("#username").val();
    var pass = $("#password").val();
    $.ajax({
        url:"/login",
        data:{"host":host,"username":user,"password":pass},
        type:"POST",
        datatype:"TEXT",
        success:function(data){
            if (data=="code error"){
                $("#news").html("code error!");
            }else if(data.indexOf("Connect failed") != -1 || data.indexOf("mysqli_connect()") != -1) {
                $("#news").html(data);
            }else if(data=="login success"){
                window.location.href="/query";
            }else{
                window.location.href="/query";
            }
        },
    });
});