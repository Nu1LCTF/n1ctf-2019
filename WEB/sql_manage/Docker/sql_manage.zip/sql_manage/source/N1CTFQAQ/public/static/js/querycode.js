$(document).ready(function(){
    $.ajax({
        url:"/getcode",
        type:"GET",
        datatype:"TEXT",
        success:function(data){
            $("#verify").html("Code:"+data);
        }

    });
});
$("#logout").click(function(){
    $.ajax({
        url:"/logout",
        type:"GET",
        datatype:"TEXT",
        success:function(data){
            window.location.href="/index";
        }

    });
});
$("#button").click(function(){
    var dbname = $("#dbname").val();
    var query = $("#query").val();
    var code = $("#code").val();
    $.ajax({
        url:"/query",
        data:{"dbname":dbname,"query":query,"code":code},
        type:"POST",
        datatype:"json",
        success:function(data){
            if (data=="code error"){
                $("#news").html("code error!");
            }else if(data=="no result"){
                $("#news").html("no result");
            }else if(data.indexOf("Connect failed") != -1 || data.indexOf("mysqli_connect()") != -1){
                $("#news").html(data);
            }else{
                $("#news").html(data);
            }
        },
        error:function(){
            $("#news").html("error");
        },
    });
    $.ajax({
        url:"/getcode",
        type:"GET",
        datatype:"TEXT",
        success:function(data){
            $("#verify").html("Code:"+data);
        }

    });
});