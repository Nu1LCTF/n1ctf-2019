#!/bin/bash
while : 1
do
    chmod 744 /tmp/*
done